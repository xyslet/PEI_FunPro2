
// Array para armazenar as tarefas

let tarefas = [];

// Seletores

const taskInput = document.getElementById('taskInput');

const addBtn = document.getElementById('addBtn');

const taskList = document.getElementById('taskList');

const filterBtns = document.querySelectorAll('.filter-btn');

// Variável para controlar filtro atual

let filtroAtual = 'todas';

// --- Funções ---

// 1. Função para adicionar tarefa

function adicionarTarefa() {

    const textoTarefa = taskInput.value.trim(); // .trim() remove espaços em branco do início e fim

    // Validação: Não permitir adicionar tarefa vazia (Recurso Bônus Nível 1)

    if (textoTarefa === '') {

        alert('Por favor, digite uma tarefa!');

        return; // Sai da função se a tarefa estiver vazia

    }

    const novaTarefa = {

        id: Date.now(), // Gera um ID único usando o timestamp atual

        texto: textoTarefa,

        concluida: false

    };

    tarefas.push(novaTarefa);

    renderizarTarefas();

    taskInput.value = ''; // Limpa o campo de input

    taskInput.focus(); // Coloca o foco de volta no campo de input

}

// 2. Função para renderizar tarefas

function renderizarTarefas() {

    taskList.innerHTML = ''; // Limpa a lista atual antes de renderizar

    let tarefasFiltradas = [];

    // Aplica o filtro selecionado

    if (filtroAtual === 'ativas') {

        tarefasFiltradas = tarefas.filter(tarefa => !tarefa.concluida);

    } else if (filtroAtual === 'concluidas') {

        tarefasFiltradas = tarefas.filter(tarefa => tarefa.concluida);

    } else { // 'todas'

        tarefasFiltradas = tarefas;

    }

    tarefasFiltradas.forEach(tarefa => {

        const li = document.createElement('li');

        li.classList.add('task-item'); // Adiciona a classe CSS para estilização

        if (tarefa.concluida) {

            li.classList.add('concluida'); // Adiciona a classe se a tarefa estiver concluída

        }

        li.innerHTML = `

            <span>${tarefa.texto}</span>

            <div class="task-actions">

                <button class="toggle-btn" data-id="${tarefa.id}">${tarefa.concluida ? 'Desfazer' : 'Concluir'}</button>

                <button class="remove-btn" data-id="${tarefa.id}">Remover</button>

            </div>

        `;

        taskList.appendChild(li);

    });

    atualizarContadorAtivas(); // Atualiza o contador de tarefas ativas (Recurso Bônus Nível 1)

}

// 3. Função para remover tarefa

function removerTarefa(id) {

    // Usa .filter() para criar um novo array sem a tarefa com o ID especificado

    tarefas = tarefas.filter(tarefa => tarefa.id !== id);

    renderizarTarefas();

}

// 4. Função para alternar conclusão

function toggleConcluida(id) {

    // Usa .map() para criar um novo array, alterando o estado 'concluida' da tarefa encontrada

    tarefas = tarefas.map(tarefa => {

        if (tarefa.id === id) {

            return { ...tarefa, concluida: !tarefa.concluida }; // Cria um novo objeto com o estado invertido

        }

        return tarefa; // Retorna a tarefa original se o ID não corresponder

    });

    renderizarTarefas();

}

// Função para atualizar o contador de tarefas ativas (Recurso Bônus Nível 1)

function atualizarContadorAtivas() {

    const contadorSpan = document.querySelector('.contador-ativas'); // Assumindo que você terá um span com essa classe no HTML

    if (contadorSpan) {

        const tarefasAtivas = tarefas.filter(tarefa => !tarefa.concluida).length;

        contadorSpan.textContent = tarefasAtivas;

    }

}

// --- Event Listeners ---

// Listener para o botão de adicionar

addBtn.addEventListener('click', adicionarTarefa);

// Listener para adicionar tarefa ao pressionar Enter no input (Recurso Bônus Nível 1)

taskInput.addEventListener('keypress', function(event) {

    if (event.key === 'Enter') {

        adicionarTarefa();

    }

});

// Listener para os botões de filtro

filterBtns.forEach(btn => {

    btn.addEventListener('click', () => {

        filtroAtual = btn.getAttribute('data-filter'); // Pega o valor do atributo data-filter

        // Atualiza a classe 'active' nos botões de filtro

        filterBtns.forEach(b => b.classList.remove('active'));

        btn.classList.add('active');

        renderizarTarefas(); // Renderiza as tarefas com base no novo filtro

    });

});

// Listener para eventos de clique na lista de tarefas (Event Delegation)

taskList.addEventListener('click', (event) => {

    const target = event.target;

    const idTarefa = parseInt(target.getAttribute('data-id')); // Pega o ID da tarefa

    // Verifica se o clique foi em um botão de remover

    if (target.classList.contains('remove-btn')) {

        removerTarefa(idTarefa);

    }

    // Verifica se o clique foi em um botão de concluir/desfazer

    else if (target.classList.contains('toggle-btn')) {

        toggleConcluida(idTarefa);

    }

});

// --- Inicialização ---

// Renderiza as tarefas existentes ao carregar a página (se houverem, por exemplo, com LocalStorage)

renderizarTarefas();